// Copyright (c) 2001/2009, Marco Borgna (mailto:borgna.marco@gmail.com)
#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <tchar.h>
#include "main.h"

void RefreshDirectory(LPTSTR);
void RefreshTree(LPTSTR);
extern winmain gW;
void WatchDirectory1(LPTSTR lpDir);
unsigned long __stdcall Threadwatch(LPVOID lpParam)
{
	WatchDirectory1((LPTSTR)lpParam);
	return 0;
}
void WatchDirectory1(LPTSTR lpDir)
{
   DWORD dwWaitStatus; 
   HANDLE dwChangeHandles[2]; 
   TCHAR lpDrive[4];
   TCHAR lpFile[_MAX_FNAME];
   TCHAR lpExt[_MAX_EXT];

   _tsplitpath(lpDir, lpDrive, NULL, lpFile, lpExt);

   lpDrive[2] = (TCHAR)'\\';
   lpDrive[3] = (TCHAR)'\0';
 
// Watch the directory for file creation and deletion. 
 
   dwChangeHandles[0] = FindFirstChangeNotification( 
      lpDir,                         // directory to watch 
      FALSE,                        
			FILE_NOTIFY_CHANGE_FILE_NAME|FILE_NOTIFY_CHANGE_SIZE); // watch file name changes 
 
   if (dwChangeHandles[0] == INVALID_HANDLE_VALUE) 
      ExitProcess(GetLastError()); 
 
// Watch the subtree for directory creation and deletion. 
 
   dwChangeHandles[1] = FindFirstChangeNotification( 
      lpDrive,                       // directory to watch 
      TRUE,                          // watch the subtree 
      FILE_NOTIFY_CHANGE_DIR_NAME|FILE_NOTIFY_CHANGE_SIZE);  // watch dir. name changes 
 
   if (dwChangeHandles[1] == INVALID_HANDLE_VALUE) 
      ExitProcess(GetLastError()); 
 
// Change notification is set. Now wait on both notification 
// handles and refresh accordingly. 
 
   while (TRUE) 
   { 
   // Wait for notification.
 
      dwWaitStatus = WaitForMultipleObjects(2, dwChangeHandles, 
         FALSE, INFINITE); 
 
      switch (dwWaitStatus) 
      { 
         case WAIT_OBJECT_0: 
 
         // A file was created or deleted in the directory.
         // Refresh this directory and restart the notification.
 
            RefreshDirectory(lpDir); 
            if ( FindNextChangeNotification( 
                    dwChangeHandles[0]) == FALSE ) 
                ExitProcess(GetLastError()); 
            break; 
 
         case WAIT_OBJECT_0 + 1: 
 
         // A directory was created or deleted in the subtree.
         // Refresh the tree and restart the notification.
 
            RefreshTree(lpDrive); 
            if (FindNextChangeNotification( 
                    dwChangeHandles[1]) == FALSE) 
                ExitProcess(GetLastError()); 
            break; 
 
        default: 
            ExitProcess(GetLastError()); 
      }
   }
}

void RefreshDirectory(LPTSTR lpDir)
{
	SetWindowText( gW.hWnd, lpDir);
}

void RefreshTree(LPTSTR lpDrive)
{
	SetWindowText( gW.hWnd, lpDrive);

}