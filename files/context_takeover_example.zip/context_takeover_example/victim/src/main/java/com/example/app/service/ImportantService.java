package com.example.app.service;

public interface ImportantService {

    String doSeriousWork();

}
