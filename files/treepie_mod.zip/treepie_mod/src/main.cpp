/**********************************************************
FILE:	main.cpp
AUTHOR:	Marco Borgna borgna.marco@gmail.com
DATE:	August 2001

note:

	Windows message loop and obj creation

***********************************************************
Copyright (c) 2001/2009, Marco Borgna (mailto:borgna.marco@gmail.com)
*/

#include <windows.h>
#include <shellapi.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <vector>

#include <commctrl.h>
#include <stdio.h>
#include <math.h>
#include <string>
#include <shlobj.h>
#include "Shlwapi.h"
#include "alldir.h"
#include "displayer.h"
#include "treeview.h"
#include "main.h"		// Classi di winmain
#include "OpenfileBox.h"		// Classi di winmain


bool DrawSplash();
extern unsigned long __stdcall Threadwatch(LPVOID lpParam);

/* Windows globals, defines, and prototypes */
CHAR szAppName[]="TreePie";


#define SWAPBUFFERS SwapBuffers(gW.hDC)
#define BLACK_INDEX     0
#define WHITE_INDEX     1

#define RED_INDEX       13
#define GREEN_INDEX     14
#define BLUE_INDEX      16
#define WIDTH           600
#define HEIGHT          400
#define WM_COMPLETE     (WM_USER + 0)


LONG WINAPI MainWndProc (HWND, UINT, WPARAM, LPARAM);
BOOL bSetupPixelFormat(HDC);


#define GLOBE    1
#define FIND	 2
#define WM_SHELLNOTIFY WM_USER+2

GLvoid resize(GLsizei, GLsizei,GLsizei, GLsizei);
GLvoid initializeGL();
GLvoid drawScene(void);
DWORD WINAPI createObjects(LPVOID  );

void mb_log(char * );

/*AllDir Globals*/
W32AllDir g_icAllDir((W32AllDir *)0);

W32AllDir *g_icFoundPtr=0;
W32AllDir *g_icCurrentPtr = &g_icAllDir;
HANDLE ghThread = 0;
bool gScanning = false;

//double gnStartAngle=0.;
double pi=3.141592654;
bool gbCreate= FALSE;
bool gbAnimate=FALSE;

winmain gW ;

 GLuint	base;

// NEHE :D
GLvoid BuildFont(void)								// Build Our Bitmap Font
{
	HFONT	font;										// Windows Font ID
	HFONT	oldfont;									// Used For Good House Keeping

	base = glGenLists(96);								// Storage For 96 Characters

	font = CreateFont(	-12,							// Height Of Font
						0,								// Width Of Font
						0,								// Angle Of Escapement
						0,								// Orientation Angle
						FW_BOLD,						// Font Weight
						FALSE,							// Italic
						FALSE,							// Underline
						FALSE,							// Strikeout
						ANSI_CHARSET,					// Character Set Identifier
						OUT_TT_PRECIS,					// Output Precision
						CLIP_DEFAULT_PRECIS,			// Clipping Precision
						ANTIALIASED_QUALITY,			// Output Quality
						FF_DONTCARE|DEFAULT_PITCH,		// Family And Pitch
						"Arial");						// Font Name

	oldfont = (HFONT)SelectObject(gW.hDC, font);           // Selects The Font We Want
	wglUseFontBitmaps(gW.hDC, 32, 96, base);				// Builds 96 Characters Starting At Character 32
	SelectObject(gW.hDC, oldfont);							// Selects The Font We Want
	DeleteObject(font);									// Delete The Font
}

GLvoid KillFont(void)									// Delete The Font List
{
	glDeleteLists(base, 96);							// Delete All 96 Characters
}




int WINAPI WinMain (HINSTANCE hInstance,
					HINSTANCE hPrevInstance,
					LPSTR lpCmdLine,
					int nCmdShow)
{
    MSG        msg;
    WNDCLASS   wndclass;

	gW.hInst= hInstance;
    /* Register the frame class */
    wndclass.style         = CS_DBLCLKS;
    wndclass.lpfnWndProc   = (WNDPROC)MainWndProc;
    wndclass.cbClsExtra    = 0;
    wndclass.cbWndExtra    = 0;
    wndclass.hInstance     = hInstance;
    wndclass.hIcon         = LoadIcon (hInstance, szAppName);
    wndclass.hCursor       = LoadCursor (NULL,IDC_ARROW);
    wndclass.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
    wndclass.lpszMenuName  = szAppName;
    wndclass.lpszClassName = szAppName;

    if (!RegisterClass (&wndclass) )
        return FALSE;

    // creo la finestre
    gW.hWnd = CreateWindow (szAppName,
             "TreePie - http://treepie.sf.net",
         WS_OVERLAPPEDWINDOW | WS_CLIPSIBLINGS | WS_CLIPCHILDREN ,
             CW_USEDEFAULT,
             CW_USEDEFAULT,
             WIDTH,
             HEIGHT,
             NULL,
             NULL,
             hInstance,
             NULL);

    // win ?
    if (!gW.hWnd)
        return FALSE;

        if (strlen(lpCmdLine)>0) // sandro manni fix
        {
                //parametri
                int len = strlen(lpCmdLine);
                if (len>=2 && lpCmdLine[0]=='"' && lpCmdLine[len-1]=='"')
                        lstrcpyn(gW.lpCmdLine, &lpCmdLine[1],len-1);
                else
                        lstrcpy(gW.lpCmdLine, lpCmdLine);
        }
        else
		{
			CBrowseForFolder sb(gW.hWnd, 0,"TreePie.sf.net:\n Choose a folder or a drive to scan:");
			sb.SetFlags(BIF_RETURNONLYFSDIRS | BIF_STATUSTEXT );
			sb.SetSelection((char *)NULL);
			if (sb.SelectFolder())
			{
				lstrcpy(gW.lpCmdLine, sb.GetSelectedFolder());
			}else{
				PostQuitMessage(0);
			}
	}

	/*gW.hStatusWnd = CreateWindow(STATUSCLASSNAME,"",
		WS_CHILD|WS_VISIBLE,0,0,0,0,gW.hWnd,NULL,hInstance,NULL);
*/
	/* show and update main window */
    ShowWindow (gW.hWnd, nCmdShow);
	InitCommonControls( );
    UpdateWindow (gW.hWnd);
	// complicate loop to support animation (still not implemented)
	do
	{
		while ( gbAnimate && PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE) == TRUE  ){
			if (GetMessage(&msg, NULL, 0, 0) ){
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			} else {
				return TRUE;
			}
		}
		while( !gbAnimate && GetMessage( &msg, NULL, 0, 0 ) ) {
			TranslateMessage( &msg );
			DispatchMessage( &msg );
		}
		if (gbAnimate && gbCreate)
			drawScene();
	}while (gbAnimate) ;
return 0;
}

void manage_WM_CREATE(HWND hWnd)
{
		RECT rect;
        gW.hDC = GetDC(hWnd);

        if (!bSetupPixelFormat(gW.hDC))
				MessageBox (NULL, "bSetupPixelFormat failed!", NULL, MB_OK );
        gW.hRC = wglCreateContext(gW.hDC);
        wglMakeCurrent(gW.hDC, gW.hRC);
        GetClientRect(hWnd, &rect);
		resize(0,0,rect.right, rect.bottom);
        initializeGL();


}


void manage_WM_COMPLETE(HWND hWnd,WPARAM wParam,LPARAM lParam)
{
	RECT rect;

    GetClientRect(hWnd, &rect);
	resize(0,0,rect.right, rect.bottom);

	drawScene();

}
void manage_WM_SIZE(HWND hWnd,WPARAM wParam,LPARAM lParam)
{
	RECT rect;
	GetClientRect(hWnd, &rect);

	resize(0,0,rect.right, rect.bottom);

	drawScene();

}


void manage_WM_LBUTTONDOWN(HWND hWnd,WPARAM  wParam, LPARAM  lParam)
{

	double nAngle,nX,nY,Dummy;
	RECT rect;
	GLdouble mp[16], mw[16];
	GLint vw[4];

	GetClientRect(hWnd,&rect);

	// calcolo nX e ny rispetto al centro
	nX = (double) LOWORD(lParam);
	nY = (double) HIWORD(lParam);

	glGetDoublev( GL_MODELVIEW_MATRIX, mw);
	glGetDoublev( GL_PROJECTION_MATRIX, mp);
	glGetIntegerv(GL_VIEWPORT,vw);

	//punti nella view !
	gluUnProject( nX, nY,0.0f,mw,mp,vw,&nX ,&nY,&Dummy);

	// angolo
	nAngle = 360-((atan2( nX ,nY )+pi)/(2*pi)) *360.0 ;

	W32AllDir *icFound;
	static W32AllDir *icOldFound=0;

	g_icFoundPtr =0;
	//cerco nella lista distanza e angolo
	if ( g_icCurrentPtr->Find( sqrt(nX*nX+nY*nY),nAngle,(AllDir**)&icFound)>=0 )
	{
		gluUnProject( 0., 30.,0.0f,mw,mp,vw,&nX ,&nY,&Dummy);

		g_icFoundPtr = icFound;

		drawScene();
	} else
	{
	/*	char sbuffer[2000];
		sprintf(sbuffer,"%f %f nAngle %f %s ",nX,nY,nAngle," ok");
		SendMessage(gW.hStatusWnd, SB_SETTEXT, (WPARAM) 0,(LPARAM) sbuffer);*/
	}
}


void startup()
{
	glClearColor(0,0,0,0);
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	glPushMatrix();
		glPushMatrix();
			glScalef(0.09,0.09,0.09);
			glRotatef (-45.0 + rand()%5, 1.0, 0.0, 0.0);
			glTranslated(-6.0,0.0,-2.0);

			DrawSplash();
		glPopMatrix();

		glColor3ub(250,250,255);
		glTranslated(0.0,0.0,-0.1);
		glRasterPos2f(-2.0, 1.2);
		glPrint("working ");

		if(strlen(gW.lpCmdLine)>0)
		{
			glRasterPos2f(-2.0, 1.0);
			char sBuffer[1024];
			lstrcpy(sBuffer,gW.lpCmdLine);
			glPrint(sBuffer);
		}
	glPopMatrix();
	glFlush ();

	SWAPBUFFERS;

	if ( !gScanning ){ //&& !ghThread
		g_icFoundPtr = 0;
		DWORD dwThreadId;

		ghThread = CreateThread(
			NULL,                       // default security attributes
			0,                          // use default stack size
			createObjects,              // thread function
			0,							// argument to thread function
			0,                          // use default creation flags
			&dwThreadId);               // returns the thread identifier
	}
}
/* main window procedure */
LONG WINAPI MainWndProc (
    HWND    hWnd,
    UINT    uMsg,
    WPARAM  wParam,
    LPARAM  lParam)
{
    LONG    lRet = 1;
    PAINTSTRUCT    ps;

    switch (uMsg) {

		case WM_CREATE:
				manage_WM_CREATE( hWnd);
			break;


		case WM_RBUTTONDOWN:
			if (!gScanning)
				manage_WM_LBUTTONDOWN(hWnd,wParam, lParam);

			if (!gScanning)
				if (g_icFoundPtr)
					ShellExecute(hWnd, "explore", g_icFoundPtr->GetName(), NULL, NULL, SW_SHOWNORMAL);
			break;

		case WM_PAINT:
			if (!gbCreate){
				BeginPaint(hWnd, &ps);
				startup();
				EndPaint(hWnd, &ps);

			}else{
				if (!gScanning)
				{
					BeginPaint(hWnd, &ps);
					drawScene();
					EndPaint(hWnd, &ps);
				}

			}
			break;
		case WM_COMPLETE:
			manage_WM_COMPLETE(hWnd,wParam,lParam);
			break;

		case WM_SIZE:
			if (!gScanning)
				manage_WM_SIZE(hWnd,wParam,lParam);
			break;

		case WM_CLOSE:
			if (gW.hRC)
				wglDeleteContext(gW.hRC);
			if (gW.hDC)
				ReleaseDC(hWnd, gW.hDC);
			gW.hRC = 0;
			gW.hDC = 0;

			DestroyWindow (hWnd);
			break;

		case WM_DESTROY:
			KillFont();
			if (gW.hRC)
				wglDeleteContext(gW.hRC);
			if (gW.hDC)
				ReleaseDC(hWnd, gW.hDC);

			PostQuitMessage (0);
			break;

		/*case WM_LBUTTONDOWN:
			manage_WM_LBUTTONDOWN(hWnd,wParam, lParam);

		break;*/

		case WM_LBUTTONDBLCLK:
			if (!gScanning){
				manage_WM_LBUTTONDOWN(hWnd,wParam, lParam);

				if (g_icFoundPtr && g_icFoundPtr->iv_nStep != 1)
					g_icCurrentPtr = g_icFoundPtr;
				else if (g_icFoundPtr && g_icFoundPtr->iv_nStep == 1)
					g_icCurrentPtr = &g_icAllDir;

				g_icFoundPtr = NULL;

				drawScene();
			}

		break;

		case WM_MOUSEMOVE:
			if (!gScanning)
				manage_WM_LBUTTONDOWN(hWnd,wParam, lParam);
		break;
      case WM_KEYDOWN:
		  if (!gScanning)
            switch (wParam)
            {
                case VK_LEFT:

                    // Process the LEFT ARROW key.

                    break;

                case VK_RIGHT:

                    // Process the RIGHT ARROW key.

                    break;

                case VK_UP:

                    // Process the UP ARROW key.

                    break;

                case VK_DOWN:

                    // Process the DOWN ARROW key.

                    break;
                case VK_F5:

                    // Process the F5 key.
					BeginPaint(hWnd, &ps);
						startup();
					EndPaint(hWnd, &ps);

                    break;


                // Process other non-character keystrokes.

                default:
                    break;
            }

		default:
			lRet = DefWindowProc (hWnd, uMsg, wParam, lParam);
			break;
    }

    return lRet;
}

BOOL bSetupPixelFormat(HDC hdc)
{
    PIXELFORMATDESCRIPTOR pfd, *ppfd;
    int pixelformat;

    ppfd = &pfd;

    ppfd->nSize = sizeof(PIXELFORMATDESCRIPTOR);
    ppfd->nVersion = 1;
    ppfd->dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL |  PFD_DOUBLEBUFFER;
                       // PFD_DOUBLEBUFFER; PFD_SUPPORT_GDI
    ppfd->dwLayerMask = PFD_MAIN_PLANE;
    ppfd->iPixelType = PFD_TYPE_RGBA;//PFD_TYPE_COLORINDEX;
    ppfd->cColorBits = 8;
    ppfd->cDepthBits = 16;
    ppfd->cAccumBits = 0;
    ppfd->cStencilBits = 0;

    pixelformat = ChoosePixelFormat(hdc, ppfd);

    if ( (pixelformat = ChoosePixelFormat(hdc, ppfd)) == 0 )
    {
        MessageBox(NULL, "ChoosePixelFormat failed", "Error", MB_OK);
        return FALSE;
    }

    if (SetPixelFormat(hdc, pixelformat, ppfd) == FALSE)
    {
        MessageBox(NULL, "SetPixelFormat failed", "Error", MB_OK);
        return FALSE;
    }

    return TRUE;
}

/* OpenGL code */

GLvoid resize( GLsizei x, GLsizei y,GLsizei width, GLsizei height )
{
    GLfloat aspect;

/*	char s[1024];
	mb_log("resize: \n");
	mb_log("\tglViewport( x, y, width, height ): \n");

	sprintf(s,"\tx: %d y: %d w: %d h: %d\n",x,y,width,height);
	mb_log(s);
*/
	glViewport( x, y, width, height );
	if ( width > height ){
		aspect = (GLfloat) width / height;
		glMatrixMode( GL_PROJECTION );
		glLoadIdentity();
		gluOrtho2D( -3.0*aspect, 3.0*aspect, -3.0, 3.0);
	}else{
		aspect = (GLfloat) height / width;
		glMatrixMode( GL_PROJECTION );
		glLoadIdentity();
		gluOrtho2D( -3.0, 3.0, -3.0*aspect, 3.0*aspect);
	}
    glMatrixMode( GL_MODELVIEW );
}

DWORD WINAPI createObjects(LPVOID lpParam )
{
	gScanning =true;
	g_icCurrentPtr = &g_icAllDir;
	if (lstrlen(gW.lpCmdLine)>0){
		char sBuffer[1024];

		lstrcpy(sBuffer,gW.lpCmdLine);
		lstrcat(sBuffer,"\\");

		g_icCurrentPtr->ListAllDir(sBuffer,gW.lpCmdLine);

	}else{
		g_icCurrentPtr->ListAllDir("c:\\","c:");
	}

	gbCreate= true;
	gScanning =false;

	DWORD lTime = GetCurrentTime () ;
	PostMessage (gW.hWnd, WM_COMPLETE, 0, lTime);


	return 0;
}

DWORD WINAPI deleteObjects( )
{
	g_icCurrentPtr->FreeAll();
	return 0;
}

GLvoid initializeGL()
{
    glClearColor( .9f,.9f,.9f,1.f);
    glClearDepth( 1.0 );
    glEnable(GL_DEPTH_TEST);
	BuildFont();
}

GLvoid drawScene(void)
{
	glClearColor(1,1,1,0);
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
    glPushMatrix();
	//
	glTranslated(0.0,0.0,-0.9);


	g_icCurrentPtr->Paint(360.0f,0,1,0,FALSE);
	// todo fix this double call and use vertex buffer


	glPopMatrix();

	if (g_icFoundPtr){

		g_icFoundPtr->Repaint(TRUE, "","");

		char sbuffer[2040];
		sprintf(sbuffer,"current root: '%s'",g_icFoundPtr->GetName()  );

		if (g_icCurrentPtr != &g_icAllDir)
			g_icFoundPtr->StatusMessage(sbuffer,"UP");
		else
			g_icFoundPtr->StatusMessage(sbuffer," ");




	}else {

		char sbuffer[2040];
		sprintf(sbuffer,"current root: '%s'",g_icCurrentPtr->GetName()  );

		g_icCurrentPtr->StatusMessage(sbuffer," ");

	}

    SWAPBUFFERS;
}



GLvoid glPrint(const char *fmt, ...)					// Custom GL "Print" Routine
{
	char		text[256];								// Holds Our String
	va_list		ap;										// Pointer To List Of Arguments

	if (fmt == NULL)									// If There's No Text
		return;											// Do Nothing

	va_start(ap, fmt);									// Parses The String For Variables
	    vsprintf(text, fmt, ap);						// And Converts Symbols To Actual Numbers
	va_end(ap);											// Results Are Stored In Text

	glPushAttrib(GL_LIST_BIT);							// Pushes The Display List Bits
	glListBase(base - 32);								// Sets The Base Character to 32
	glCallLists(strlen(text), GL_UNSIGNED_BYTE, text);	// Draws The Display List Text
	glPopAttrib();										// Pops The Display List Bits
}




// DEBUG FUNCTIONS
// ---------------

void mb_log(char * sL)
{
/*
	FILE *f;
	f=fopen("c:\\easylog.txt","a+");
	fprintf(f,sL);
	fclose(f);*/
}
