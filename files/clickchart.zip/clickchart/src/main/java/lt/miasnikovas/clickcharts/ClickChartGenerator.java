package lt.miasnikovas.clickcharts;

import java.io.*;
import java.util.*;
import java.text.*;
import org.jfree.chart.*;
import org.jfree.data.time.*;
import org.jfree.chart.renderer.xy.XYItemRenderer;

public class ClickChartGenerator
{
    private Map load(String fname) {
        int nr = 1;
        Map data = new HashMap();
        try {
            String line = null;
            String[] arr = null;
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(fname)));
            while(true)
            {
                line = br.readLine();
                if(line==null) break;
                arr = line.split(" ");
                double db = Double.parseDouble(arr[3]) + Double.parseDouble(arr[6]) + Double.parseDouble(arr[9]);
                data.put(arr[0], db);
                nr++;
            }
            br.close();
        }
        catch(FileNotFoundException e) {
            System.out.println("No previous data found");
        }
        catch(Exception e) {
            System.out.println("Could not load data from file '"+fname+"' (line "+nr+")");
            e.printStackTrace();
        }
        
        //sort data before returning
        return new TreeMap(data);
    }

    private void chart(Map data) {
        String line = null;
        int year, month, day;
        String name = "Clicks per day";

        try {
            TimeSeriesCollection timeseriescollection = new TimeSeriesCollection();
            TimeSeries tseries = new TimeSeries(name, Day.class);
            
            double last = 0;
            Iterator it = data.keySet().iterator();
            while(it.hasNext())
            {
                String date = (String) it.next();
                double value = (Double) data.get(date);
                
                String[] arr = date.split("/");
                year = Integer.valueOf(arr[2]);
                month = Integer.valueOf(arr[1]);
                day = Integer.valueOf(arr[0]);
                
                tseries.add(new Day(day, month, year), value);
                last = value;
            }

            TimeSeries avg_series = MovingAverage.createMovingAverage(tseries, "Monthly moving average", 30, 1);

            timeseriescollection.addSeries(tseries);
            timeseriescollection.addSeries(avg_series);

            JFreeChart jfreechart = ChartFactory.createTimeSeriesChart(name, "Day", "Clicks", timeseriescollection, true, true, false);
            jfreechart.setAntiAlias(true);
            jfreechart.setBorderVisible(true);
            XYItemRenderer xyitemrenderer = jfreechart.getXYPlot().getRenderer();
            ChartUtilities.saveChartAsPNG(new File("clicks.png"), jfreechart, 570, 300);
        }
        catch(Exception e) {
            System.out.println("Could not create chart");
            e.printStackTrace();
        }
    }
    
    public void generate(String filename) {
        chart(load(filename));
    }
}
