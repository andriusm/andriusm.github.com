/**********************************************************
FILE:	treeview.cpp
AUTHOR:	Marco Borgna
DATE:	August 2001

note:

	Trivial treeview management

***********************************************************/
/*Copyright (c) 2003, Marco Borgna (mailto:olly.move@iol.it)
All rights reserved.

Redistribution and use in source and binary forms, 
with or without modification, are permitted provided 
that the following conditions are met:

Redistributions of source code must retain the above copyright notice, 
this list of conditions and the following disclaimer. 
Redistributions in binary form must reproduce the above copyright notice, 
this list of conditions and the following disclaimer in the documentation 
and/or other materials provided with the distribution. 

  Neither the name of  Marco Borgna nor the names of its contributors 
  may be used to endorse or promote products derived from this software without 
  specific prior written permission. 

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND 
 CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, 
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
 DISCLAIMED. 
 IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
 LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, 
 OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
 OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
 OF SUCH DAMAGE.
*/

#include <windows.h>    // includes basic windows functionality
#include <commctrl.h>   // includes the common control header
#include <string.h>
#include "treeview.h"
#include "resource.h"


// image list indices
int idxFolder;
int idxFolderOpen;

// Drag and drop boolean
BOOL g_fDragging = FALSE;

HWND CreateTreeView (HWND hWndParent,HINSTANCE hInst)                                     
{
	HWND hwndTree;      // handle to tree view window
	RECT rcl;           // rectangle for setting size of window
	HBITMAP hBmp;       // handle to a bitmap
	HIMAGELIST hIml;    // handle to image list

	// Ensure that the common control DLL is loaded.
	InitCommonControls();

	// Get the size and position of the parent window.
	GetClientRect(hWndParent, &rcl);

	// Create thre tree view window.
	hwndTree = CreateWindowEx( 0L,
		WC_TREEVIEW,						// tree view class
		"",                   		        // no default text
		WS_VISIBLE | WS_CHILD | WS_BORDER | TVS_HASLINES | TVS_HASBUTTONS | 
			TVS_LINESATROOT |TVS_SHOWSELALWAYS ,
		0, 0,
		getTVwidth(&rcl),
		rcl.bottom,
		hWndParent,
		(HMENU) ID_TREEVIEW,
		hInst,
		NULL );

	if (hwndTree == NULL )
		return NULL;

	// Initialize the tree view window.
	// First create the image list you will need.
	hIml = ImageList_Create( BITMAP_WIDTH,  // width
	    BITMAP_HEIGHT,                      // height
		0,                                  // creation flags
		2,			                        // number of images
		10 );                                // amount this list can grow

	// Load the bitmaps and add them to the image list.
	hBmp = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_FOLDER));
	idxFolder = ImageList_Add(hIml,        // handle to imagelist
	                           hBmp,        // handle of bitmap to add
	                           NULL);       // handle of bitmap mask

	// Load the bitmaps and add them to the image list.
	hBmp = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_FOLDEROPEN));
	idxFolderOpen = ImageList_Add(hIml,        // handle to imagelist
	                           hBmp,        // handle of bitmap to add
	                           NULL);       // handle of bitmap mask

	// Associate the image list with the tree view control.
	TreeView_SetImageList(hwndTree, hIml, idxFolder);

	return (hwndTree);
}


/*
// This function saves the current image and the handle to the
// parent of the tree view item.
VOID FillInStruct(HTREEITEM hParent, int iImage, int index, int iMax)
{
	for (;index < iMax; index++)
	{
		rgHouseInfo[index].iImage = iImage;
		rgHouseInfo[index].hParent = hParent;
	}
}*/

/***************************************************************************
* 
*    FUNCTION: AddOneItem(HTREEITEM, LPSTR, HTREEITEM, int)
*
*    PURPOSE: Inserts a tree view item in the specified place. 
*
****************************************************************************/

// This function fills out the TV_ITEM and TV_INSERTSTRUCT structures
// and adds the item to the tree view control.
HTREEITEM AddOneItem( HTREEITEM hParent, LPSTR szText, HTREEITEM hInsAfter, 
	int iImage, 
	HWND hwndTree,void * pAllDir)
{
	HTREEITEM hItem;
	TV_ITEM tvI;
	TV_INSERTSTRUCT tvIns;

	// The pszText, iImage, and iSelectedImage are filled out.
	tvI.mask = TVIF_TEXT | TVIF_IMAGE | TVIF_SELECTEDIMAGE | TVIF_PARAM;
	tvI.pszText = szText;
	tvI.cchTextMax = lstrlen(szText);
	tvI.iImage = idxFolder;
	tvI.iSelectedImage = idxFolderOpen;
	tvI.lParam = (LPARAM ) pAllDir;
	tvIns.item = tvI;
	tvIns.hInsertAfter = hInsAfter;
	tvIns.hParent = hParent;
	
	// Insert the item into the tree.
	hItem = (HTREEITEM)SendMessage(hwndTree, TVM_INSERTITEM, 0, 
		(LPARAM)(LPTV_INSERTSTRUCT)&tvIns);

	return (hItem);

}


// SIZE FUNCTION
long getTVwidth(RECT *rect){
	return ((rect->right>TREEVIEW_SIZE*2)?TREEVIEW_SIZE:rect->right/2 );
}

long getTVheight(RECT *rect){

	return (rect->bottom-20);
}
