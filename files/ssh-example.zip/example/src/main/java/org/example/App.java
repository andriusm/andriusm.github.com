package org.example;

import java.io.*;

import com.trilead.ssh2.*;

/**
 * Created by IntelliJ IDEA.
 * User: Andrius Miasnikovas
 * Date: 2011-10-17
 * Time: 3:27 PM
 */
public class App {

    private static final String HOSTNAME = "localhost";
    private static final String USERNAME = "username";

    /**
     * Used for user/pwd authentication. If you want to use this method of
     * authentication make sure that your /etc/sshd_config file contains a line:
     * 
     * PasswordAuthentication yes
     */
    private static final String PASSWORD = "password";

    /**
     * Used for private/public key authentication.
     * Read this if you need more info on how to generate a keypair
     * 
     * http://www.debian-administration.org/articles/152
     */
    private static final File PEM_KEY_FILE = new File("privatekey.pem");
    private static final String KEY_PASSWORD = "password";

    public static void main(String[] args) throws IOException {

        //Establishing a connection to the host
        boolean isAuth = false;
        Connection conn = new Connection(HOSTNAME);
        conn.connect();

        //Use only one of the following two authentication methods
        isAuth = conn.authenticateWithPublicKey(USERNAME, PEM_KEY_FILE, KEY_PASSWORD);
        //isAuth = conn.authenticateWithPassword(USERNAME, PASSWORD);

        if (isAuth == false) {
            throw new IOException("Authentication failed.");
        }

        //Create an SSH session and execute a shell command
        Session sess = conn.openSession();
        sess.execCommand("ps a");

        //Open the server's output stream and read line by line until nothing left
        InputStream inp = sess.getStdout();
        InputStreamReader reader = new InputStreamReader(inp);
        BufferedReader br = new BufferedReader(reader);
        String line;
        while ((line = br.readLine()) != null) {
            System.out.println(line);
        }
        br.close();

        //Close server session and connection to host
        sess.close();
        conn.close();
    }
}
