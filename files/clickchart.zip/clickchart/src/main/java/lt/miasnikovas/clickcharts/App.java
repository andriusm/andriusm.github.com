package lt.miasnikovas.clickcharts;

import java.util.*;

public class App
{
    public static void main( String[] args ) throws Exception {
    	
    	if(args.length < 1) {
    		System.out.println("Usage: java -jar clickcharts.jar counter.log");
    		System.exit(1);
    	}
    	
        Locale.setDefault(Locale.US);
        ClickChartGenerator chart = new ClickChartGenerator();
        chart.generate(args[0]);
        System.out.println( "done!");
    }
}
