// gui.h: interface for the gui class.
//
//////////////////////////////////////////////////////////////////////


class gui  
{
private: 
	gui();

public:
	virtual ~gui();


};


