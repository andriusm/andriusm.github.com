package com.example.app.web;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import com.example.app.service.*;
import org.springframework.web.servlet.*;
import org.springframework.web.servlet.mvc.*;

public class HelloController implements Controller {

    private ImportantService service;

    public void setService(ImportantService service) {
        this.service = service;
    }

    public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        String result = service.doSeriousWork();
        request.getSession().setAttribute("result", result);
        return new ModelAndView("hello.jsp");
    }
}