/**********************************************************
FILE:	displayer.cpp
AUTHOR:	Marco Borgna
DATE:	August 2001

note:

  Implemetation of method used by AllDir to give output

***********************************************************
Copyright (c) 2001/2009, Marco Borgna (mailto:borgna.marco@gmail.com)
*/

#include <windows.h>
#include <commctrl.h>
#include <math.h>
#include <stdio.h>
#include <time.h>

#include <GL/gl.h>
#include <GL/glu.h>

#include "main.h"
#include "treeview.h"

#include "AllDir.h"
#include "displayer.h"

extern winmain gW;
extern GLuint	base;




AllDir* W32AllDir::newAllDir()
{
	// new with parent
	return new W32AllDir(this);
}

void W32AllDir::StatusMessage(char * sBuffer,char *  sCenterMsg){

		glColor3ub(155,67,120);

//		double s,w;
//		GetRangeFromStep(iv_nStep+2,s,w);

		//glRasterPos2f(s*sin(iv_nStartAngle/180.0*3.14) , s*cos(iv_nStartAngle/180.0*3.14));


		glMatrixMode(GL_PROJECTION);

		glPushMatrix();
			glLoadIdentity();

			RECT rect;
			GetClientRect( gW.hWnd, &rect);
			glOrtho( rect.left, rect.right, rect.top, rect.bottom,-1,1);

			glMatrixMode(GL_MODELVIEW);
			glPushMatrix();
				glLoadIdentity();

				glRasterPos2f(5.0f , rect.bottom - 20.0f );
				glPrint("%d files", iv_nSize);

				glRasterPos2f(rect.right/2.0f , rect.bottom - 20.0f );
				glPrint(sBuffer);

				glColor3ub(55,67,120);

				glRasterPos2f(5.0f , rect.bottom - 40.0f );

				glPrint("directory :");
				glPrint(GetName());

				glRasterPos2f(10,20);
				glPrint("rightclick explore | doubleclick expand | F5 full rescan");

				glColor3ub(55,67,125);
				glTranslated(0.0,0.0,1.0);
				glRasterPos2f(rect.right/2.0f -5.0f,rect.bottom/2.0f-5.0f);
				glPrint(sCenterMsg);

			glPopMatrix();

		glMatrixMode(GL_PROJECTION);
		glPopMatrix();
		glMatrixMode(GL_MODELVIEW);
};

void W32AllDir::DrawSector(double nStartAngle,double nAngle,double nStartRadius,double nRadius,bool bLit )
{

		GLUquadricObj *quadObj;
		quadObj= gluNewQuadric();
		if(quadObj)
		{
			glPushMatrix();
			long slices=(long)(nAngle/3.0);
			slices= (slices >1 ?slices:2);

			int r,g,b;

			GetColor(bLit,r,g,b);

			// GLU_SILHOUETTE
		  // ------------------------------------
			gluQuadricDrawStyle (quadObj, GLU_SILHOUETTE );
			long redComponent = 10 - (time(0) - iv_ActivityTime);
			if (redComponent <= 0)
				redComponent = 0;
			else
				redComponent=redComponent*5;

			if (bLit){
				glColor3ub(180 ,180,180);

			}
			else{
				glColor3d(r*0.55 ,r*0.55,r*0.55);//glColor3ub(55+ redComponent ,67,120);
			}

			gluPartialDisk( quadObj,
				nStartRadius,
				nRadius,
				slices,
				1,
				nStartAngle,
				nAngle    	);

			if (bLit){
				glColor3ub(148+ redComponent,169,201);
			}
			else{
				glColor3ub(255 ,255 - redComponent,255 - redComponent);
			}

			// GLU_FILL
			// ------------------------------------
			gluQuadricDrawStyle (quadObj, GLU_FILL );
			gluQuadricNormals(quadObj, GLU_NONE );

			// glTranslated(0.0,0.0,-0.1);


			glColor3ub(r ,g - redComponent,b - redComponent);

			gluPartialDisk( quadObj,
				nStartRadius,
				nRadius,
				slices,
				1,
				nStartAngle,
				nAngle 	);


			glPopMatrix();
			gluDeleteQuadric(quadObj);

		}

}

