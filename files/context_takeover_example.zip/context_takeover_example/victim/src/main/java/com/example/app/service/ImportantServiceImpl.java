package com.example.app.service;

public class ImportantServiceImpl implements ImportantService {

    public String doSeriousWork() {
        return "The result of hard work from the important service";
    }
}
