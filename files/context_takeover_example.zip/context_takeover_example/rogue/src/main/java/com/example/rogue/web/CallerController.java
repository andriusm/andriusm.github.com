package com.example.rogue.web;

import java.io.*;
import java.lang.reflect.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.springframework.context.support.*;
import org.springframework.web.servlet.*;
import org.springframework.web.servlet.mvc.*;

public class CallerController implements Controller {

    public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        ClassPathXmlApplicationContext rogueCtx = Model.getInstance().getAppContext();
        Object o = rogueCtx.getBean("importantService");

        for(Method method : o.getClass().getMethods()) {
            if(method.getName().equalsIgnoreCase("doSeriousWork")) {
                try {
                    Object result = method.invoke(o);
                    request.getSession().setAttribute("result", result);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        return new ModelAndView("caller.jsp");
    }
}