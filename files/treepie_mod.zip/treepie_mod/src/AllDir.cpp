/**********************************************************
FILE:	AllDir.h
AUTHOR:	Marco Borgna
DATE:	August 2001

note:

	Logic of search (some day would be extracted in a virtual class
	and memory data scheme creation)

***********************************************************
Copyright (c) 2001/2009, Marco Borgna (mailto:borgna.marco@gmail.com)
*/

// Windows Header Files:
#include <windows.h>
#include <commctrl.h>
#include <math.h>
#include <stdio.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <time.h>


//extern HWND ghStatusWnd;
#include "alldir.h"
#include "treeview.h"
extern void WatchDirectory1(LPTSTR lpDir);
extern void mb_log(char * );

//funzione di confronto usata dal quicksort
int compare( const void *arg1, const void *arg2 ){
	AllDir **a1;
	AllDir **a2;
	a1=(AllDir**) arg1;
	a2=(AllDir**) arg2;

	if ( (*a1)->iv_nSize < (*a2)->iv_nSize )
		return 1;
	else
		return -1;
   };

void AllDir::setActivity( )
{
	iv_ActivityTime = time(0);
}


void AllDir::FreeAll( )
{
	// free childrens before
	for (int ia=0;ia<iv_nLevelDir;ia++){
		iv_aList[ia]->FreeAll();
	}
	// and this then
	free(iv_aList);
	return;
}

// scansione delle sotto directory di sFile
//(deve essere una dir con lo slash finale)
INT64 AllDir::ListAllDir( LPSTR sFile,LPSTR sDirName)
{
	HANDLE hFirst;
	WIN32_FIND_DATA hFind;
	INT64 nSize = -2;

	char sCompleteFile[MAX_PATH];
	char sListFile[MAX_PATH];
	long nLevelDir;

	// aggiungo "*.*" assume la DIR con \ finale
	lstrcpy(sListFile, sFile);
	lstrcat(sListFile,"*.*");

	// azzero il conto delle directory
	nLevelDir=0;

	//ciclo su tutti le dir della dir per contarle
	hFirst = FindFirstFile( sListFile , &hFind );
	do {
		if ( (hFind.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) &&
			!(hFind.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT)  &&
			 ( hFind.cFileName[strlen((char*)hFind.cFileName)-1]!='.') )
		{
			nLevelDir++;

		}
	}while ( FindNextFile (hFirst,&hFind) );

	FindClose(hFirst);

	// first an array of pointer
	iv_aList= (AllDir **) malloc( sizeof(AllDir* ) * nLevelDir);

	//just a hack to create the right derived obj at runtime
	for (int ia=0;ia<nLevelDir;ia++){
		iv_aList[ia] = this->newAllDir();
	}

	// copio nome e numero di subdir
	lstrcpy(iv_sDirName, sFile);
	iv_nLevelDir = nLevelDir;

	// calling virtual function
//	AddTreeItem(sDirName);

	//ciclo sulle subdir
    int j = 0;
	hFirst = FindFirstFile( sListFile , &hFind );
	do {
		// se � una dir
		if ( (hFind.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) &&
			!(hFind.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT) &&
			 ( hFind.cFileName[strlen(hFind.cFileName)-1]!='.') )
		{
			// aggiungo lo slash e mi richiamo
			lstrcpy(sCompleteFile, sFile);
			lstrcat(sCompleteFile,hFind.cFileName);
			lstrcat(sCompleteFile,"\\");

			/*char buff[1024];
			sprintf(buff,"Now searching: %s (%d/%d)",sCompleteFile,j+1,iv_nLevelDir);
			*/
			nSize += iv_aList[j]->ListAllDir( sCompleteFile,hFind.cFileName);
			j++;
		}else
		{

			if (hFind.nFileSizeHigh!=-858993460 ) //// ARRRGH!(system information folder)
			{
				//grandezza del file (aritmetica a 64 bit)
				nSize++;
				//if (nSize > MAXDWORD){
				//	mb_log("ListAllDir: nSize sorpassa MAXDWORD");
				//}

				//char sBuffer[1024];
				//sprintf(sBuffer,"%s(hFind.nFileSizeHigh  ) : %d (nSize)[%I64d]\n",sDirName,hFind.nFileSizeHigh,nSize );

				//mb_log(sBuffer);
			}
		}
	}while ( FindNextFile (hFirst,&hFind) );
	FindClose(hFirst);
    iv_nSize = nSize ;

	// metto in ordine
	if ( iv_bSorted ==1 )
	{
		qsort( (void *)iv_aList, (size_t) iv_nLevelDir , sizeof( AllDir*  ), compare );
	}

	return nSize;
}

double AllDir::Repaint(bool bLit, char  * sbuffer,char  * sCenterMsg)
{

	glPushMatrix();
	//glTranslated(0.0,0.0,0.2);
	double pippo= Paint(iv_nSweepAngle,iv_nStartAngle,iv_nStep,iv_nSize,bLit);


	glPopMatrix();
	return pippo;
}

double AllDir::Paint(double nAngle,double nStartAngle,int nStep,INT64 nUpSize,bool bLit)
{
	// calcolo l'angolo a partire dall'angolo
	// che mi � stato passato
	// in proporzione alle dimensioni di questa dir e quella sopra
	// ------------------------------------------------------------

	if (nStep!=1)
		nAngle = (iv_nSize * nAngle  / nUpSize) ;


	// salvo i dati che verranno usati in ricerca !
	// ------------------------------------------------------------
	iv_nStartAngle = nStartAngle;
	iv_nSweepAngle = nAngle;
	iv_nStep = nStep;

	// calcolo il raggio interno e esterno
	// ------------------------------------------------------------
	double nStartRadius;
	double nRadius;

  GetRangeFromStep ( nStep, nStartRadius, nRadius );


	//escludo le dir troppo piccole
	if (fabs(nAngle)>0.1 )
	{
		// Disegno il settore
		DrawSector(nStartAngle,nAngle,nStartRadius,nRadius,bLit);
	}
	nStep++;

	// ciclo nella lista
	for ( int i=0; i<iv_nLevelDir; i++)
	{
	  nStartAngle += iv_aList[i]->Paint(nAngle,  nStartAngle , nStep,iv_nSize,bLit);
	}


	return nAngle;
}

int AllDir::Find(double nRadius, double nAngle, AllDir** icFound)
{
	if ( (nAngle < iv_nStartAngle) || ( nAngle > iv_nStartAngle + iv_nSweepAngle) )
		return -1;
	double nStartRadius;
	double nEndRadius;
    GetRangeFromStep ( iv_nStep, nStartRadius, nEndRadius );
	if ( (nRadius >= nStartRadius ) && (nRadius <= nEndRadius )) {
		*icFound=this;
		return 1;
	}
	else {
		for (int i=0; i<iv_nLevelDir; i++)
			if ( iv_aList[i]->Find( nRadius,nAngle,icFound) > 0)
				return 1;
	}
	return -2;
}

/*int AllDir::Find( char * lpDir, AllDir** icFound)
{
	long currDir = 0;
	while( currDir < iv_nLevelDir ){
		unsigned int l = strlen(lpDir);
		unsigned int p = 0;
		while (p<=l ){ //&& p<l2){
			if (iv_aList[currDir]->iv_sDirName[p]!=  lpDir[p]	  &&
				iv_aList[currDir]->iv_sDirName[p]!= (lpDir[p]+32) &&
				iv_aList[currDir]->iv_sDirName[p]!= (lpDir[p]-32)
				){
				break;
			}
		p++;
		}
		// EQUAL --> FOUND!
		if (p==(l+1) || (p==l && iv_aList[currDir]->iv_sDirName[p]=='\\' ) ) {
			*icFound=iv_aList[currDir];
			return 1;
		}
		// still not foun but  partially matching
		if (p == strlen(iv_aList[currDir]->iv_sDirName)) {
			return iv_aList[currDir]->Find(lpDir,icFound) ;
		}

		currDir++;

	}
	return 0;

}*/

int AllDir::GetRangeFromStep (int nStep,
						  double &nStartRadius,
						  double &nRadius )
{
	// calcolo nStartRadius
	nStartRadius=0.;
	nRadius=0.;
	for (int j=1; j<nStep; j++)
	{
		nStartRadius += (1/pow(1.1,j));
	}
	nStartRadius = nStartRadius * RADIUS;
	nRadius = nStartRadius + (1/pow(1.1,nStep) )* RADIUS;
	return 0;
}
int palettelen = 28;
int curcolor[3] ;
int palette[] =
{
229,236,255,
255,229,249,
229,249,255,
168,191,255,
107,147,255,
255,229,236,
229,255,248,
255,216,107,
255,232,168,
255,235,229,
229,255,235,
236,255,229,
249,255,229,
255,248,229,
229,236,255,
255,229,249,
229,249,255,
168,191,255,
107,147,255,
255,229,236,
229,255,248,
255,216,111,
255,232,158,
255,235,221,
229,255,234,
236,255,220,
249,255,229,
255,248,228

};

boolean first=false;
int AllDir::GetColor( bool blit, int &r,int &g,int &b   )
{
	if (iv_nStep>0){

		r = 250;
		g = 250;
		b = 250;
	}
	int pos =(int) iv_nStartAngle/360.0*palettelen;
	if (iv_nStep==2){
		r = palette[pos*3]*0.9;
		g = palette[pos*3+1]*0.9;
		b = palette[pos*3+2]*0.9;
		curcolor[0]=r*1.01;
		curcolor[1]=g*1.01;
		curcolor[2]=b*1.01;

	}
	if (iv_nStep>2){
		r = curcolor[0];
		g = curcolor[1];
		b = curcolor[2];
	}
	if (blit){
		r = 10;
		g = 248;
		b = 10;
	}

	return 0;
}
