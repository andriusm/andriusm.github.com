package com.example.rogue.web;

import java.io.*;
import java.net.*;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import org.apache.catalina.loader.*;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

public class ContextListener implements ServletContextListener {

    private final String DEFAULT_SPRING_CONFIG = "classpath:rogue-context.xml";

    public void contextInitialized(ServletContextEvent event) {
        ServletContext servletContext = event.getServletContext();
        String springConfig = servletContext.getInitParameter("spring.config.location");
        if (springConfig == null || springConfig.trim().isEmpty()) springConfig = DEFAULT_SPRING_CONFIG;

        WebApplicationContext webContext = WebApplicationContextUtils.getWebApplicationContext(servletContext);
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(webContext);
        context.setClassLoader(getModifiedClassLoader());
        context.setAllowBeanDefinitionOverriding(true);
        context.setConfigLocation(springConfig);

        long begin = System.currentTimeMillis();
        context.refresh();
        long end = System.currentTimeMillis();
        System.out.println(context.getBeanDefinitionCount() + " Spring beans loaded in " + (end - begin) + " ms");

        Model.getInstance().setAppContext(context);
    }

    public void contextDestroyed(ServletContextEvent event) {
        System.out.println("Destroying webapp context");
        Model.getInstance().destroy();
    }

    /**
     * Scans the lib directory of victim application and adds all
     * the jar files as valid repositories for the current application
     */
    private WebappClassLoader getModifiedClassLoader() {
        WebappClassLoader classLoader = (WebappClassLoader) this.getClass().getClassLoader();

        String tmp = classLoader.getURLs()[0].getPath();
        String appDir = tmp.substring(1, tmp.indexOf("/webapps/") + 8);
        String classesDir = appDir + "/victim/WEB-INF/classes/";
        String libDir = appDir + "/victim/WEB-INF/lib/";

        classLoader.addRepository("file:/"+classesDir);
        File dir = new File(libDir);
        for (String file : dir.list()) {
            if (file.endsWith(".jar")) {
                classLoader.addRepository("file:/" + libDir + file);
            }
        }
        return classLoader;
    }
}

