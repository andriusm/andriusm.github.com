package com.example.rogue.web;

import org.springframework.context.support.*;

public class Model {
    private static Model _instance = null;
    private ClassPathXmlApplicationContext appContext;

    protected static synchronized Model getInstance() {
        if (_instance == null) {
            try {
                _instance = new Model();
            } catch (Exception e) {
                _instance = null;
            }
        }
        return _instance;
    }

    protected ClassPathXmlApplicationContext getAppContext() {
        return appContext;
    }

    protected void setAppContext(ClassPathXmlApplicationContext applicationContext) {
        if (appContext != null) throw new RuntimeException("Can only set the application context once");
        this.appContext = applicationContext;
    }

    protected void destroy() {
        if(appContext!=null) {
            appContext.close();
        }
        appContext = null;
        _instance = null;
        System.gc();
    }
}
